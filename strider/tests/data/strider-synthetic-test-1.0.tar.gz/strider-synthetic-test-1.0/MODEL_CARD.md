# strider-synthetic-test (version 1.0)

A synthetic model for the tests.
