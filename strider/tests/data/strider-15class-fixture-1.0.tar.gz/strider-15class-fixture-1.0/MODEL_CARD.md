# strider-15class-fixture (version 1.0)

A model with random weights, for the package's tests. It is not a science model.

- **Classes:** Ia, 91bg, Iax, IIP, IIL, IIb, IIn, Ib, Ic, Ic-BL, SLSN, TDE, ILOT, KN, PISN.
- **Redshift grid:** 500 cells from 0.000 to 3.000, uniform in ln(1 + z).
- **Wavelength range:** 7500–18175 Å in the observer frame. A visit that does not cover it is not used.
- **Fingerprint:** `a7732d9e31226c9d97e124add6c3428e9f3f5a5745fa695c4b7e04f3afec4a83`, which identifies
  `model_config.json`, `weights.pt`, `spectral_model.pt`, `brightness.npz`, `preprocessing.json` and `priors.json`.

## How it works

STRIDER compares the combined spectrum of the visits with each class's spectra at every redshift. It also compares
each visit's brightness in four observed bands, 7500–18000 Å, with each class's light curves. The two are added with
weights fitted on held-out simulations: 0.879 for the spectrum and 0.444 for the brightness. A class gets no
probability at a redshift where it had no training transients.

## Training data

Not yet measured.

## Valid range

Not yet measured.

## Priors

The model's training prior and survey prior are in `priors.json`. The survey prior is a fake survey population for the
fixtures: more objects at low redshift. The class probabilities and the redshift posterior use the survey prior.

## Metrics

Not yet measured.

## Calibration

`model_config.json` holds the two weights, and `calibration.json` the calibration of the source probability.

## Known failures

Not yet measured.
